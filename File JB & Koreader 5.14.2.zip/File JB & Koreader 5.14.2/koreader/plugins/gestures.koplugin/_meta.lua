local _ = require("gettext")
return {
    name = "gestures",
    fullname = _("Gestures"),
    description = _([[This plugin provides gesture support.]]),
}
