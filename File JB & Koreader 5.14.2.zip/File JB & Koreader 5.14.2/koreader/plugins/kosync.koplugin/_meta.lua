local _ = require("gettext")
return {
    name = "kosync",
    fullname = _("Progress sync"),
    description = _([[Synchronizes your reading progess to a server across your KOReader devices.]]),
}
