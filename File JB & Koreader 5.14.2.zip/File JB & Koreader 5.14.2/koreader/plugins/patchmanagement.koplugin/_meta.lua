local _ = require("gettext")
return {
    name = "patch_management",
    fullname = _("Patch management"),
    description = _("This plugin allows enabling, disabling or editing user patches."),
}
