local _ = require("gettext")
return {
    name = "wallabag",
    fullname = _("Wallabag"),
    description = _([[Synchronises articles with a Wallabag server.]]),
}
