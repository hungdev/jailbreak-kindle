local _ = require("gettext")
return {
    name = "statistics",
    fullname = _("Reading statistics"),
    description = _([[Keeps and displays your reading statistics.]]),
}
