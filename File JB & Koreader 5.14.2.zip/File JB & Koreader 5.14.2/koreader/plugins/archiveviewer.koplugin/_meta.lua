local _ = require("gettext")
return {
    name = "archiveviewer",
    fullname = _("Archive viewer"),
    description = _([[Enables exploring the content of zip archives.]]),
}
