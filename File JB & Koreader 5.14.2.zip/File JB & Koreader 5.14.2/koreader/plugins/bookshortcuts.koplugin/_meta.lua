local _ = require("gettext")
return {
    name = "bookshortcuts",
    fullname = _("Book shortcuts"),
    description = _([[This plugin allows adding a book shortcut to a gesture.]]),
}
