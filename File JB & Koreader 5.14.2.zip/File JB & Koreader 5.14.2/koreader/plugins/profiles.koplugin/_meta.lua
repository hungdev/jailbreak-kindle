local _ = require("gettext")
return {
    name = "profiles",
    fullname = _("Profiles"),
    description = _([[This plugin allows combining multiple settings to make switchable 'profiles'.]]),
}
