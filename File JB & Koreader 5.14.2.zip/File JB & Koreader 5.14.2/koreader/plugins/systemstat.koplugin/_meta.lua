local _ = require("gettext")
return {
    name = "systemstat",
    fullname = _("System statistics"),
    description = _([[Shows system statistics.]]),
}
