local _ = require("gettext")
return {
    name = "movetoarchive",
    fullname = _("Move to archive"),
    description = _([[Moves/copies current book to archive folder]]),
}
