Use at your own risk. Tested on Kindle PW3 5.8.1 ONLY.


http://www.mobileread.com/forums/showthread.php?t=276501


by lucida